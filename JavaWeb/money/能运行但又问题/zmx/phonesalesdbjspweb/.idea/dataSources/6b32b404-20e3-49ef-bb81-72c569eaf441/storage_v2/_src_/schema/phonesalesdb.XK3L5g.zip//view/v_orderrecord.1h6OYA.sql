create view v_orderrecord as
select `phonesalesdb`.`t_orderrecord`.`saleid`       AS `saleid`,
       `phonesalesdb`.`t_orderrecord`.`productid`    AS `productid`,
       `phonesalesdb`.`t_orderrecord`.`salequantity` AS `salequantity`,
       `phonesalesdb`.`t_orderrecord`.`saleamount`   AS `saleamount`,
       `phonesalesdb`.`t_orderrecord`.`saletime`     AS `saletime`,
       `phonesalesdb`.`t_orderrecord`.`useraccount`  AS `useraccount`,
       `phonesalesdb`.`t_orderrecord`.`recordstatus` AS `recordstatus`,
       `phonesalesdb`.`t_product`.`productname`      AS `productname`,
       `phonesalesdb`.`t_product`.`brand`            AS `brand`,
       `phonesalesdb`.`t_product`.`memory`           AS `memory`,
       `phonesalesdb`.`t_product`.`price`            AS `price`,
       `phonesalesdb`.`t_product`.`colortype`        AS `colortype`,
       `phonesalesdb`.`t_product`.`productlmage`     AS `productlmage`,
       `phonesalesdb`.`t_user`.`pwd`                 AS `pwd`,
       `phonesalesdb`.`t_user`.`username`            AS `username`,
       `phonesalesdb`.`t_user`.`utid`                AS `utid`,
       `phonesalesdb`.`t_user`.`idnumber`            AS `idnumber`,
       `phonesalesdb`.`t_user`.`mobile`              AS `mobile`
from ((`phonesalesdb`.`t_orderrecord` join `phonesalesdb`.`t_product` on ((`phonesalesdb`.`t_orderrecord`.`productid` =
                                                                           `phonesalesdb`.`t_product`.`productid`)))
         join `phonesalesdb`.`t_user`
              on ((`phonesalesdb`.`t_orderrecord`.`useraccount` = `phonesalesdb`.`t_user`.`useraccount`)));

